import pyb
from usched import Timeout, Roundrobin
PINLIST = ('Y1','Y2','Y6','Y5','Y4','Y3')
class LCD(object):
 INITSTRING = (0x33, 0x32, 0x28, 0x0C, 0x06, 0x01)
 LCD_LINES = (0x80, 0xC0)
 CHR = True
 CMD = False
 E_PULSE = 50
 E_DELAY = 50
 def __init__(self, pinlist, scheduler, cols, rows = 2):
  self.initialising = True
  self.LCD_E = pyb.Pin(pinlist[1], pyb.Pin.OUT_PP)
  self.LCD_RS = pyb.Pin(pinlist[0], pyb.Pin.OUT_PP)
  self.datapins = [pyb.Pin(pin_name, pyb.Pin.OUT_PP) for pin_name in pinlist[2:]]
  self.cols = cols
  self.rows = rows
  self.lines = [""]*self.rows
  self.dirty = [False]*self.rows
  for thisbyte in LCD.INITSTRING:
   self.lcd_byte(thisbyte, LCD.CMD)
   self.initialising = False
  scheduler.add_thread(runlcd(self))
 def lcd_nybble(self, bits):
  for pin in self.datapins:
   pin.value(bits & 0x01)
   bits >>= 1
  pyb.udelay(LCD.E_DELAY)
  self.LCD_E.value(True)
  pyb.udelay(LCD.E_PULSE)
  self.LCD_E.value(False)
  if self.initialising:
   pyb.delay(5)
  else:
   pyb.udelay(LCD.E_DELAY)
 def lcd_byte(self, bits, mode):
  self.LCD_RS.value(mode)
  self.lcd_nybble(bits >>4)
  self.lcd_nybble(bits)
 def __setitem__(self, line, message):
  message = "%-*.*s" % (self.cols,self.cols,message)
  if message != self.lines[line]:
   self.lines[line] = message
   self.dirty[line] = True
 def __getitem__(self, line):
  return self.lines[line]
def runlcd(thislcd):
 wf = Timeout(0.02)
 rr = Roundrobin()
 while(True):
  for row in range(thislcd.rows):
   if thislcd.dirty[row]:
    msg = thislcd[row]
    thislcd.lcd_byte(LCD.LCD_LINES[row], LCD.CMD)
    for thisbyte in msg:
     thislcd.lcd_byte(ord(thisbyte), LCD.CHR)
     yield rr
    thislcd.dirty[row] = False
  yield wf()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
