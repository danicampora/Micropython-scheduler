import pyb
from usched import Sched, Roundrobin, Timeout
def stop(fTim, objSch):
 yield Timeout(fTim)
 objSch.stop()
def robin(text):
 wf = Roundrobin()
 while True:
  print(text)
  yield wf()
def robin_test(duration = 0):
 objSched = Sched()
 objSched.add_thread(robin("Thread 1"))
 objSched.add_thread(robin("Thread 2"))
 objSched.add_thread(robin("Thread 3"))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
robin_test(5)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
