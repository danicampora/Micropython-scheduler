import pyb
from usched import Sched, Roundrobin, wait
def stop(fTim, objSch):
 yield from wait(fTim)
 objSch.stop()
def robin(text):
 wf = Roundrobin()
 while True:
  print(text)
  yield wf()
def test(duration = 0):
 objSched = Sched()
 objSched.add_thread(robin("Thread 1"))
 objSched.add_thread(robin("Thread 2"))
 objSched.add_thread(robin("Thread 3"))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
test(5)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
