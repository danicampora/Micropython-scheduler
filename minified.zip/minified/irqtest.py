import pyb
from usched import Sched, Poller, Timeout, Pinblock, wait
from switch import Switch
def stop(fTim, objSch):
 yield from wait(fTim)
 objSch.stop()
def oscillator(freq_hz = 1):
 outpin = pyb.Pin(pyb.Pin.board.X7, pyb.Pin.OUT_PP)
 wf = Timeout(1/(2*freq_hz))
 while True:
  outpin.low()
  yield wf()
  outpin.high()
  yield wf()
class Irq_handler(object):
 def __init__(self, lstLed, testpin):
  self.lstLed = lstLed
  self.testpin = testpin
 def callback(self, irqno):
  self.testpin.high()
  self.testpin.low()
  self.lstLed[1].toggle()
def irqtest_thread():
 lstLeds = [pyb.LED(x) for x in range(1,5)]
 testpin = pyb.Pin(pyb.Pin.board.Y10, pyb.Pin.OUT_PP)
 mypin = pyb.Pin.board.X8
 han = Irq_handler(lstLeds, testpin)
 wf = Pinblock(mypin, pyb.ExtInt.IRQ_FALLING, pyb.Pin.PULL_NONE, han.callback)
 count = 0
 while True:
  result = (yield wf())
  lstLeds[0].toggle()
  print("Interrupt recieved ", result)
def x5print(*args):
 print("X5 released " +args[0])
def x6print(*args):
 print("X6 pressed " + args[0])
def test(duration = 0):
 if duration:
  print("Test interrupt on pin X8 for {:3d} seconds".format(duration))
 objSched = Sched()
 objSched.add_thread(oscillator(1))
 objSched.add_thread(irqtest_thread())
 Switch(objSched, 'X5', open_func = x5print, open_func_args = ("Red",))
 Switch(objSched, 'X6', x6print, ("Yellow",))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
test(30)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
