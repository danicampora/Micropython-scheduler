from usched import Sched, wait
from pushbutton import Pushbutton, descriptor
def stop(fTim, objSch):
 yield from wait(fTim)
 objSch.stop()
def x5print(*args):
 print("X5 released " +args[0])
def x6print(*args):
 print("X6 pressed " + args[0])
def yellowlong(*args):
 print(args[0] +" yellow")
def yellowdbl(*args):
 print(args[0] +" yellow")
def test(duration = 0):
 if duration:
  print("Tests pushbuttons for {:5d} seconds".format(duration))
 else:
  print("Tests pushbuttons")
 objSched = Sched()
 Pushbutton(objSched, 'X5', descriptor, false_func = x5print, false_func_args = ("Red",))
 Pushbutton(objSched, 'X6', descriptor, true_func = x6print, true_func_args = ("Yellow",), long_func = yellowlong, long_func_args = ("Long press",), double_func = yellowdbl, double_func_args = ("Double click",))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
test(20)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
