from usched import Sched
from pushbutton import Pushbutton, descriptor
def x5print(*args):
 print("X5 released " +args[0])
def x6print(*args):
 print("X6 pressed " + args[0])
def yellowlong(*args):
 print(args[0] +" yellow")
def yellowdbl(*args):
 print(args[0] +" yellow")
def test(duration = 0):
 objSched = Sched()
 Pushbutton(objSched, 'X5', descriptor, false_func = x5print, false_func_args = ("Red",))
 Pushbutton(objSched, 'X6', descriptor, true_func = x6print, true_func_args = ("Yellow",), long_func = yellowlong, long_func_args = ("Long press",), double_func = yellowdbl, double_func_args = ("Double click",))
 objSched.run()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
