from usched import Sched, microsWhen, seconds, after, microsUntil, Timeout
class Delay(object):
 def __init__(self, objSched, callback = None, callback_args = ()):
  self.objSched = objSched
  self.callback = callback
  self.callback_args = callback_args
  self._running = False
 def stop(self):
  self._running = False
 def trigger(self, duration):
  self.tstop = microsWhen(seconds(duration))
  if not self._running:
   self.objSched.add_thread(self.killer())
   self._running = True
 def running(self):
  return self._running
 def killer(self):
  to = Timeout(1)
  while not after(self.tstop):
   yield to._ussetdelay(microsUntil(self.tstop))
  if self._running and self.callback:
   self.callback(*self.callback_args)
  self._running = False
# Created by pyminifier (https://github.com/liftoff/pyminifier)
