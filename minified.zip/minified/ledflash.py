import pyb
from usched import Sched, wait
def stop(fTim, objSch):
 yield from wait(fTim)
 objSch.stop()
def toggle(objLED, time):
 while True:
  yield from wait(time)
  objLED.toggle()
def test(duration = 0):
 if duration:
  print("Flash LED's for {:3d} seconds".format(duration))
 leds = [pyb.LED(x) for x in range(1,5)]
 objSched = Sched()
 for x in range(4):
  objSched.add_thread(toggle(leds[x], 0.2 + x/2))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
test(10)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
