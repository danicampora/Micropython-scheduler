import pyb
from usched import Sched, Timeout
def stop(fTim, objSch):
 yield Timeout(fTim)
 objSch.stop()
def toggle(objLED, time):
 while True:
  yield Timeout(time)
  objLED.toggle()
def ledtest(duration = 0):
 print("Flash LED's for {:3d} seconds".format(duration))
 leds = [pyb.LED(x) for x in range(1,5)]
 objSched = Sched()
 for x in range(4):
  objSched.add_thread(toggle(leds[x], 0.2 + x/2))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
ledtest(10)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
