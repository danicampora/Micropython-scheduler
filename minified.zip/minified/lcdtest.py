import pyb
from usched import Sched, wait
from lcdthread import LCD, PINLIST
def stop(fTim, objSch):
 yield from wait(fTim)
 objSch.stop()
def lcd_thread(mylcd):
 mylcd[0] = "MicroPython"
 while True:
  mylcd[1] = "{:11d}uS".format(pyb.micros())
  yield from wait(1)
def test(duration = 0):
 if duration:
  print("Test LCD display for {:3d} seconds".format(duration))
 objSched = Sched()
 lcd0 = LCD(PINLIST, objSched, cols = 16)
 objSched.add_thread(lcd_thread(lcd0))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
test(20)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
