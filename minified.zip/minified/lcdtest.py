import pyb
from usched import Sched, Timeout
from usched import micros
from lcdthread import LCD, PINLIST
def stop(fTim, objSch):
 yield Timeout(fTim)
 objSch.stop()
def lcd_thread(mylcd):
 mylcd[0] = "MicroPython"
 while True:
  mylcd[1] = "{:10d}uS".format(micros.counter())
  yield Timeout(1)
def lcdtest(duration = 0):
 print("Test LCD display for {:3d} seconds".format(duration))
 objSched = Sched()
 lcd0 = LCD(PINLIST, objSched, cols = 16)
 objSched.add_thread(lcd_thread(lcd0))
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
lcdtest(20)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
