import pyb
from usched import Sched, Timeout
from delay import Delay
descriptor = dict()
descriptor['no'] = True
descriptor['grounded'] = True
descriptor['pull'] = pyb.Pin.PULL_UP
descriptor['debounce'] = 0.02
descriptor['long_press_time'] = 1
descriptor['double_click_time'] = 0.4
class Pushbutton(object):
 def __init__(self, objSched, pinName, desc, true_func = None, true_func_args = (), false_func = None, false_func_args = (), long_func = None, long_func_args = (), double_func = None, double_func_args =()):
  self.pin = pyb.Pin(pinName, pyb.Pin.IN, desc['pull'])
  self.desc = desc
  self.objSched = objSched
  self.true_func = true_func
  self.true_func_args = true_func_args
  self.false_func = false_func
  self.false_func_args = false_func_args
  self.long_func = long_func
  self.long_func_args = long_func_args
  self.double_func = double_func
  self.double_func_args = double_func_args
  self.sense = not desc['no']^desc['grounded']
  self.buttonstate = self.rawstate()
  objSched.add_thread(self.buttoncheck())
 def rawstate(self):
  return bool(self.pin.value() ^ self.sense)
 def __call__(self):
  return self.buttonstate
 def buttoncheck(self):
  wf = Timeout(self.desc['debounce'])
  state_id = 0
  if self.long_func:
   longdelay = Delay(self.objSched, self.long_func, self.long_func_args)
  if self.double_func:
   doubledelay = Delay(self.objSched)
  while True:
   state = self.rawstate()
   if state != self.buttonstate:
    self.buttonstate = state
    if state:
     if self.long_func and not longdelay.running():
      longdelay.trigger(self.desc['long_press_time'])
     if self.double_func:
      if doubledelay.running():
       self.double_func(*self.double_func_args)
      else:
       doubledelay.trigger(self.desc['double_click_time'])
     if self.true_func:
      self.true_func(*self.true_func_args)
    else:
     if self.long_func and longdelay.running():
      longdelay.stop()
     if self.false_func:
      self.false_func(*self.false_func_args)
   yield wf()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
