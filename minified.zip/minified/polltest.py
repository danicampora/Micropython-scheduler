import pyb
from usched import Sched, Poller, wait
def stop(fTim, objSch):
 yield from wait(fTim)
 objSch.stop()
class Accelerometer(object):
 def __init__(self, accelhw):
  self.accelhw = accelhw
  self.coords = [accelhw.x(), accelhw.y(), accelhw.z()]
 def dsquared(self, xyz):
  return sum(map(lambda p, q : (p-q)**2, self.coords, xyz))
 def poll(self, threshold):
  xyz = [self.accelhw.x(), self.accelhw.y(), self.accelhw.z()]
  if self.dsquared(xyz) > threshold*threshold:
   self.coords = xyz
   return 1
  return None
 @property
 def x(self):
  return self.coords[0]
 @property
 def y(self):
  return self.coords[1]
 @property
 def z(self):
  return self.coords[2]
def accelthread():
 accelhw = pyb.Accel()
 yield from wait(0.03)
 accel = Accelerometer(accelhw)
 wf = Poller(accel.poll, (4,), 2)
 while True:
  reason = (yield wf())
  if reason[1]:
   print("Value x:{:3d} y:{:3d} z:{:3d}".format(accel.x, accel.y, accel.z))
  if reason[2]:
   print("Timeout waiting for accelerometer change")
def test(duration = 0):
 if duration:
  print("Output accelerometer values for {:3d} seconds".format(duration))
 else:
  print("Output accelerometer values")
 objSched = Sched()
 objSched.add_thread(accelthread())
 if duration:
  objSched.add_thread(stop(duration, objSched))
 objSched.run()
test(30)
# Created by pyminifier (https://github.com/liftoff/pyminifier)
