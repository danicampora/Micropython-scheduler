import pyb
import micropython
micropython.alloc_emergency_exception_buf(100)
TIMERPERIOD = 0x7fffffff
MAXTIME = TIMERPERIOD//2
MAXSECS = MAXTIME//1000000
class TimerException(Exception) : pass
def microsWhen(timediff):
 if timediff >= MAXTIME:
  raise TimerException()
 return (pyb.micros() + timediff) & TIMERPERIOD
def microsSince(oldtime):
 return (pyb.micros() - oldtime) & TIMERPERIOD
def after(trigtime):
 res = ((pyb.micros() - trigtime) & TIMERPERIOD)
 if res >= MAXTIME:
  res = 0
 return res
def microsUntil(tim):
 return ((tim - pyb.micros()) & TIMERPERIOD)
def seconds(S):
 return int(1000000*S)
def millisecs(mS):
 return int(1000*mS)
class Waitfor(object):
 def __init__(self):
  self.uS = 0
  self.timeout = microsWhen(0)
  self.forever = False
  self.irq = None
  self.pollfunc = None
  self.pollfunc_args = ()
  self.customcallback = None
  self.interruptcount = 0
  self.roundrobin = False
 def triggered(self):
  if self.irq:
   self.irq.disable()
   numints = self.interruptcount
   if numints:
    self.interruptcount = 0
   self.irq.enable()
   if numints:
    return (numints, 0, 0)
  if self.pollfunc:
   res = self.pollfunc(*self.pollfunc_args)
   if res is not None:
    return (0, res, 0)
  if not self.forever:
   if self.roundrobin:
    return (0,0,0)
   res = after(self.timeout)
   if res:
    return (0, 0, res)
  return None
 def _ussetdelay(self,uS = None):
  if uS:
   self.uS = uS
  self.timeout = microsWhen(self.uS)
  return self
 def setdelay(self, secs = None):
  if secs is None:
   self.forever = True
   return self
  else:
   self.forever = False
   return self._ussetdelay(seconds(secs))
 def __call__(self):
  if self.uS:
   return self._ussetdelay()
  return self
 def intcallback(self, irqno):
  if self.customcallback:
   self.customcallback(irqno)
  self.interruptcount += 1
class Roundrobin(Waitfor):
 def __init__(self):
  super().__init__()
  self.roundrobin = True
class Timeout(Waitfor):
 def __init__(self, tim):
  super().__init__()
  self.setdelay(tim)
def wait(secs):
 if secs <=0 :
  raise TimerException()
 count = secs // MAXSECS
 tstart = secs - count*MAXSECS
 yield Timeout(tstart)
 while count:
  yield Timeout(MAXSECS)
  count -= 1
class Pinblock(Waitfor):
 def __init__(self, pin, mode, pull, customcallback = None, timeout = None):
  super().__init__()
  self.customcallback = customcallback
  if timeout is None:
   self.forever = True
  else:
   self.setdelay(timeout)
  self.irq = pyb.ExtInt(pin, mode, pull, self.intcallback)
class Poller(Waitfor):
 def __init__(self, pollfunc, pollfunc_args = (), timeout = None):
  super().__init__()
  self.pollfunc = pollfunc
  self.pollfunc_args = pollfunc_args
  if timeout is None:
   self.forever = True
  else:
   self.setdelay(timeout)
class Sched(object):
 def __init__(self):
  self.lstThread = []
  self.bStop = False
 def stop(self):
  self.bStop = True
 def add_thread(self, func):
  try:
   self.lstThread.append([func.send(None), func])
  except StopIteration:
   print("Stop iteration error")
 def run(self):
  try:
   self._runthreads()
  except OSError as v:
   print(v)
   print("Interrupted")
 def _runthreads(self):
  while len(self.lstThread) and not self.bStop:
   self.lstThread = [thread for thread in self.lstThread if thread[1] is not None]
   lstPriority = []
   lstRoundRobin = []
   for idx, thread in enumerate(self.lstThread):
    priority = thread[0].triggered()
    if priority is not None:
     if priority == (0,0,0) :
      lstRoundRobin.append(idx)
     else:
      lstPriority.append((priority, idx))
   lstPriority.sort()
   while True:
    while len(lstPriority):
     priority, idx = lstPriority.pop(-1)
     thread = self.lstThread[idx]
     try:
      thread[0] = thread[1].send(priority)
     except StopIteration:
      self.lstThread[idx][1] = None
    if len(lstRoundRobin) == 0:
     break
    idx = lstRoundRobin.pop()
    thread = self.lstThread[idx]
    try:
     thread[0] = thread[1].send((0,0,0))
    except StopIteration:
     self.lstThread[idx][1] = None
    for idx, thread in enumerate(self.lstThread):
     priority = thread[0].triggered()
     if priority is not None and priority != (0,0,0) and thread[1] is not None:
      lstPriority.append((priority, idx))
    lstPriority.sort()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
