from usched import Sched, Roundrobin, Timeout
def subthread(lstResult):
 yield Roundrobin()
 print("Subthread started")
 yield Timeout(1)
 print("Subthread end")
 lstResult[0] = True
def waitforit(objSched):
 result = [False]
 print("Waiting on thread")
 objSched.add_thread(subthread(result))
 while not result[0]:
  yield Roundrobin()
 print("Thread returned")
def wait_test():
 print("Demonstration of subthreads")
 objSched = Sched()
 objSched.add_thread(waitforit(objSched))
 objSched.run()
wait_test()
# Created by pyminifier (https://github.com/liftoff/pyminifier)
